import tkinter as tk
from tkinter import messagebox
import numpy as np

# Функція для обробки натискань на кнопки
def button_click(row, col):
    global turn, game_board, buttons
    if game_board[row, col] == " ":
        game_board[row, col] = turn
        buttons[row][col].config(text=get_current_symbol())
        check_winner()
        turn = "X" if turn == "O" else "O"

# Функція для перевірки переможця
def check_winner():
    global turn, SIZE, game_board
    for i in range(SIZE):
        if all(game_board[i, :] == turn):
            messagebox.showinfo("Кінець гри", f"Переміг гравець {turn}!")
            root.quit()
            return
        if all(game_board[:, i] == turn):
            messagebox.showinfo("Кінець гри", f"Переміг гравець {turn}!")
            root.quit()
            return
    if np.all(np.diag(game_board) == turn):
        messagebox.showinfo("Кінець гри", f"Переміг гравець {turn}!")
        root.quit()
        return
    if np.all(np.diag(np.fliplr(game_board)) == turn):
        messagebox.showinfo("Кінець гри", f"Переміг гравець {turn}!")
        root.quit()
        return
    if np.all(game_board != " "):
        messagebox.showinfo("Кінець гри", "Нічия!")
        root.quit()
        return

# Функція для початку гри з новим розміром поля
def start_game():
    global SIZE, game_board, turn
    try:
        SIZE = int(size_entry.get())
        game_board = np.full((SIZE, SIZE), " ")
        turn = "X"
        frame.pack_forget()
        frame.pack() # Додайте цей рядок
        create_game_board()
    except:
        messagebox.showerror("Помилка!", "Розмір поля повинен бути числом.")

# Функція для створення кнопок гри
def create_game_board():
    global buttons, SIZE
    buttons = []
    for i in range(SIZE):
        row = []
        for j in range(SIZE):
            button = tk.Button(frame, text=" ", width=5, height=2,
                               command=lambda r=i, c=j: button_click(r, c))
            button.grid(row=i, column=j)
            row.append(button)
        buttons.append(row)

# Функція для отримання поточного символу
def get_current_symbol():
    global turn
    return "X" if turn == "X" else "O"

# Створення основного вікна програми
root = tk.Tk()
root.title("Гра зрестики-нулики")

# Створення вікна для вибору розміру поля
size_frame = tk.Frame(root)
size_frame.pack()

size_label = tk.Label(size_frame, text="Виберіть розмір поля:")
size_label.pack()

size_entry = tk.Entry(size_frame)
size_entry.pack()

start_button = tk.Button(size_frame, text="Почати гру", command=start_game)
start_button.pack()

# Створення вікна для гри
frame = tk.Frame(root)

# Ініціалізація матриці для зберігання даних про кнопки
SIZE = 3
game_board = np.full((SIZE, SIZE), " ")

# Оголошення глобальних змінних
turn = "X"
buttons = []

root.mainloop()
